// QuietSpot configuration.
// 1) Supabase: Dashboard > Project Settings > API
//    Paste the Project URL and the "anon / public" key below.
//    The anon key is designed to be public; your data is protected by the
//    Row Level Security policies in supabase/schema.sql.
//    NEVER put the service_role key here.
// 2) CAMPUS_CENTER: [latitude, longitude] the map opens on.
window.QUIETSPOT_CONFIG = {
  SUPABASE_URL: "https://lhgtcanwmavmmocwkwox.supabase.co",
  SUPABASE_ANON_KEY: "sb_publishable_1LseRqMq5qC0R9KnYQIdOA_7SS5Fh_N",
  CAMPUS_CENTER: [12.660688, 77.450813],
  DEFAULT_ZOOM: 17,
  PHOTO_BUCKET: "space-photos",
  REPORT_WINDOW_MINUTES: 60
};
