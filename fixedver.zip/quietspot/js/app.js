(() => {
  'use strict';

  // ------------------------------------------------------------------
  // Config & Supabase client
  // ------------------------------------------------------------------
  const cfg = window.QUIETSPOT_CONFIG || {};
  const configured = !!(cfg.SUPABASE_URL && cfg.SUPABASE_ANON_KEY &&
    !/YOUR_/.test(cfg.SUPABASE_URL + cfg.SUPABASE_ANON_KEY) && window.supabase);
  const sb = configured ? window.supabase.createClient(cfg.SUPABASE_URL, cfg.SUPABASE_ANON_KEY) : null;
  const WINDOW_MIN = cfg.REPORT_WINDOW_MINUTES || 60;
  const BUCKET = cfg.PHOTO_BUCKET || 'space-photos';
  const CENTER = cfg.CAMPUS_CENTER || [28.6139, 77.2090];
  const ZOOM = cfg.DEFAULT_ZOOM || 17;

  const LEVELS = {
    1: { label: 'Empty', cls: 'l1' }, 2: { label: 'Quiet', cls: 'l2' },
    3: { label: 'Busy', cls: 'l3' },  4: { label: 'Packed', cls: 'l4' }
  };
  const CATEGORIES = {
    library: 'Library', lecture_hall: 'Lecture hall', department: 'Department / lab',
    outdoor: 'Outdoor', cafe: 'Café / lounge', other: 'Other'
  };

  // Demo data shown only when Supabase keys are not configured yet
  const demo = (o) => Object.assign({
    floor: null, capacity: null, open_time: null, close_time: null, is_24h: false,
    has_wifi: false, has_charging: false, has_ac: false, has_water: false, has_restroom: false,
    step_free: false, has_elevator: false, accessible_restroom: false, accessibility_notes: null,
    is_official: true, is_verified: true, created_by: null, live_level: null, live_reported_at: null,
    live_report_count: 0, confirm_count: 0, flag_count: 0, cover_path: null, description: ''
  }, o);
  const DEMO = [
    demo({ id: 'd1', name: 'Silent Reading Hall', building: 'Central Library', category: 'library', floor: '2',
      description: 'Strict-silence hall with individual carrels.', latitude: 28.6145, longitude: 77.2094,
      open_time: '08:00', close_time: '22:00', has_wifi: true, has_charging: true, has_ac: true, has_water: true,
      has_restroom: true, step_free: true, has_elevator: true, accessible_restroom: true, live_level: 1,
      live_reported_at: new Date().toISOString(), live_report_count: 3 }),
    demo({ id: 'd2', name: 'Lecture Hall 3', building: 'Lecture Hall Complex', category: 'lecture_hall',
      description: 'Usually empty between classes.', latitude: 28.6134, longitude: 77.2100,
      open_time: '09:00', close_time: '18:00', has_wifi: true, has_charging: true, has_ac: true, has_water: true,
      step_free: true, live_level: 3, live_reported_at: new Date().toISOString(), live_report_count: 2 }),
    demo({ id: 'd3', name: 'Study Lounge', building: 'Engineering Block', category: 'department',
      description: 'Long tables and power strips.', latitude: 28.6149, longitude: 77.2077,
      open_time: '08:00', close_time: '20:00', has_wifi: true, has_charging: true, has_ac: true, has_water: true,
      has_elevator: true }),
    demo({ id: 'd4', name: 'Central Lawn', building: 'Central Quad', category: 'outdoor',
      description: 'Shaded lawn, calm in the mornings.', latitude: 28.6130, longitude: 77.2086, is_24h: true,
      has_water: true, step_free: true, live_level: 2, live_reported_at: new Date().toISOString(), live_report_count: 1 })
  ];

  // ------------------------------------------------------------------
  // Helpers
  // ------------------------------------------------------------------
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  let toastTimer;
  function toast(msg, type = '') {
    const t = $('#toast');
    t.textContent = msg; t.className = 'toast ' + type; t.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { t.hidden = true; }, 4200);
  }

  const toMin = (t) => { if (!t) return null; const [h, m] = t.split(':'); return (+h) * 60 + (+m); };
  function fmtTime(t) {
    if (!t) return '';
    const [h, m] = t.split(':').map(Number);
    const d = new Date(); d.setHours(h, m, 0, 0);
    return d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
  }
  function openStatus(s) {
    if (s.is_24h) return { open: true, text: 'Open 24 hours' };
    const o = toMin(s.open_time), c = toMin(s.close_time);
    if (o == null || c == null) return { open: null, text: 'Hours not listed' };
    const now = new Date(); const n = now.getHours() * 60 + now.getMinutes();
    const open = o <= c ? (n >= o && n < c) : (n >= o || n < c);
    return { open, text: `${open ? 'Open' : 'Closed'} · ${fmtTime(s.open_time)}–${fmtTime(s.close_time)}` };
  }
  function distance(a, b) { // metres, haversine
    const R = 6371000, rad = (x) => x * Math.PI / 180;
    const dLat = rad(b[0] - a[0]), dLng = rad(b[1] - a[1]);
    const h = Math.sin(dLat / 2) ** 2 + Math.cos(rad(a[0])) * Math.cos(rad(b[0])) * Math.sin(dLng / 2) ** 2;
    return 2 * R * Math.asin(Math.sqrt(h));
  }
  function fmtDist(m) {
    const walk = Math.max(1, Math.round(m / 80));
    return (m < 1000 ? Math.round(m) + ' m' : (m / 1000).toFixed(1) + ' km') + ` · ~${walk} min walk`;
  }
  function ago(iso) {
    const mins = Math.max(0, Math.round((Date.now() - new Date(iso)) / 60000));
    return mins < 1 ? 'just now' : mins + ' min ago';
  }
  const publicUrl = (path) => sb.storage.from(BUCKET).getPublicUrl(path).data.publicUrl;
  const dirUrl = (s) => `https://www.google.com/maps/dir/?api=1&destination=${s.latitude},${s.longitude}&travelmode=walking`;
  const appleUrl = (s) => `https://maps.apple.com/?daddr=${s.latitude},${s.longitude}&dirflg=w`;
  const userName = () => state.user?.user_metadata?.display_name || state.user?.email?.split('@')[0] || '';

  // ------------------------------------------------------------------
  // State
  // ------------------------------------------------------------------
  const state = {
    user: null, spaces: [], favs: new Set(),
    filters: { q: '', open: false, quiet: false, wifi: false, charging: false, accessible: false, favs: false },
    sort: 'quiet', selectedId: null, userPos: null, fitted: false,
    map: null, layer: null, pickMap: null, pickMarker: null
  };

  // ------------------------------------------------------------------
  // Data loading
  // ------------------------------------------------------------------
  async function loadSpaces() {
    if (!sb) { state.spaces = DEMO; render(); return; }
    const { data, error } = await sb.from('space_overview').select('*').order('name');
    if (error) { toast('Could not load spaces: ' + error.message, 'error'); return; }
    state.spaces = data || [];
    render();
  }
  async function loadFavs() {
    state.favs = new Set();
    if (sb && state.user) {
      const { data } = await sb.from('favourites').select('space_id');
      (data || []).forEach((r) => state.favs.add(r.space_id));
    }
    render();
  }

  // ------------------------------------------------------------------
  // Filtering, sorting, rendering
  // ------------------------------------------------------------------
  function visible() {
    const f = state.filters, q = f.q.trim().toLowerCase();
    const list = state.spaces.filter((s) => {
      if (q && !`${s.name} ${s.building} ${CATEGORIES[s.category] || ''}`.toLowerCase().includes(q)) return false;
      if (f.open && openStatus(s).open !== true) return false;
      if (f.quiet && !(s.live_level && s.live_level <= 2)) return false;
      if (f.wifi && !s.has_wifi) return false;
      if (f.charging && !s.has_charging) return false;
      if (f.accessible && !s.step_free) return false;
      if (f.favs && !state.favs.has(s.id)) return false;
      return true;
    });
    const dist = (s) => state.userPos ? distance(state.userPos, [s.latitude, s.longitude]) : Infinity;
    if (state.sort === 'name') list.sort((a, b) => a.name.localeCompare(b.name));
    else if (state.sort === 'near' && state.userPos) list.sort((a, b) => dist(a) - dist(b));
    else list.sort((a, b) => (a.live_level ?? 99) - (b.live_level ?? 99) || a.name.localeCompare(b.name));
    return list;
  }

  function cardHTML(s) {
    const lv = LEVELS[s.live_level], os = openStatus(s);
    const flagged = s.flag_count >= 2 && s.flag_count > s.confirm_count;
    const dist = state.userPos ? fmtDist(distance(state.userPos, [s.latitude, s.longitude])) : '';
    const thumb = (s.cover_path && sb)
      ? `<img src="${esc(publicUrl(s.cover_path))}" alt="Photo of ${esc(s.name)}" loading="lazy">`
      : `<div class="ph" aria-hidden="true">${esc(s.name.charAt(0))}</div>`;
    const amen = [s.has_wifi && 'Wi-Fi', s.has_charging && 'Power', s.has_ac && 'A/C', s.has_water && 'Water', s.step_free && 'Step-free']
      .filter(Boolean).map((a) => `<span>${a}</span>`).join('');
    const fav = state.favs.has(s.id);
    return `
      <article class="card ${state.selectedId === s.id ? 'sel' : ''}" data-id="${esc(s.id)}" tabindex="0">
        <div class="thumb">${thumb}</div>
        <div>
          <h3 class="title">${esc(s.name)}</h3>
          <div class="sub">${esc(s.building)}${s.floor ? ' · ' + esc(s.floor) : ''}${dist ? ' · ' + dist : ''}</div>
          <div class="badges">
            <span class="badge occ ${lv ? lv.cls : 'none'}">${lv ? lv.label : 'No recent report'}</span>
            <span class="badge ${os.open === false ? 'closed' : ''}">${esc(os.text)}</span>
            ${s.is_verified ? '<span class="badge ok">✓ Verified</span>' : ''}
            ${flagged ? '<span class="badge warn">⚠ Flagged</span>' : ''}
          </div>
          <div class="amen">${amen}</div>
        </div>
        <button class="fav ${fav ? 'on' : ''}" data-fav="${esc(s.id)}" aria-pressed="${fav}" aria-label="${fav ? 'Remove from' : 'Save to'} favourites">♥</button>
      </article>`;
  }

  function renderList(list) {
    $('#count').textContent = `${list.length} space${list.length === 1 ? '' : 's'}`;
    $('#list').innerHTML = list.length ? list.map(cardHTML).join('')
      : '<div class="empty">No spaces match. Try clearing a filter, or add one yourself!</div>';
  }

  function renderMap(list) {
    if (!state.map) return;
    state.layer.clearLayers();
    list.forEach((s) => {
      const lv = LEVELS[s.live_level];
      const icon = L.divIcon({
        className: '', iconSize: [28, 28], iconAnchor: [8, 26],
        html: `<div class="pin ${lv ? lv.cls : 'none'} ${state.selectedId === s.id ? 'sel' : ''}"></div>`
      });
      L.marker([s.latitude, s.longitude], { icon, title: s.name, keyboard: true })
        .on('click', () => openDetail(s.id)).addTo(state.layer);
    });
    if (!state.fitted && list.length) {
      state.fitted = true;
      try { state.map.fitBounds(L.latLngBounds(list.map((s) => [s.latitude, s.longitude])), { padding: [60, 60], maxZoom: 18 }); } catch (e) { /* hidden map */ }
    }
  }

  function render() { const l = visible(); renderList(l); renderMap(l); }

  // ------------------------------------------------------------------
  // Space details
  // ------------------------------------------------------------------
  async function fetchExtras(s) {
    const out = { photos: [], myReport: null, myVote: null };
    if (!sb) return out;
    const since = new Date(Date.now() - WINDOW_MIN * 60000).toISOString();
    const jobs = [
      sb.from('space_photos').select('path').eq('space_id', s.id).order('created_at')
        .then((r) => { out.photos = (r.data || []).map((p) => publicUrl(p.path)); })
    ];
    if (state.user) {
      jobs.push(sb.from('occupancy_reports').select('level,created_at').eq('space_id', s.id)
        .eq('user_id', state.user.id).gte('created_at', since).order('created_at', { ascending: false }).limit(1)
        .then((r) => { out.myReport = (r.data && r.data[0]) || null; }));
      jobs.push(sb.from('space_verifications').select('vote').eq('space_id', s.id)
        .eq('user_id', state.user.id).maybeSingle()
        .then((r) => { out.myVote = r.data ? r.data.vote : null; }));
    }
    await Promise.all(jobs);
    return out;
  }

  function detailHTML(s, x) {
    const lv = LEVELS[s.live_level], os = openStatus(s);
    const mine = state.user && s.created_by === state.user.id;
    const fav = state.favs.has(s.id);
    const gallery = x.photos.length
      ? x.photos.map((u) => `<img src="${esc(u)}" alt="Photo of ${esc(s.name)}">`).join('')
      : `<div class="ph" aria-hidden="true">${esc(s.name.charAt(0))}</div>`;
    const dist = state.userPos ? fmtDist(distance(state.userPos, [s.latitude, s.longitude])) : '';
    const fac = (on, label) => `<span class="fac ${on ? '' : 'off'}">${label}</span>`;
    const nextAt = x.myReport ? new Date(new Date(x.myReport.created_at).getTime() + WINDOW_MIN * 60000)
      .toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }) : '';
    const levelBtns = [1, 2, 3, 4].map((n) => `
      <button class="level-btn ${x.myReport && x.myReport.level === n ? 'mine' : ''}" data-action="report" data-level="${n}" ${x.myReport ? 'disabled' : ''}>
        <i class="${LEVELS[n].cls}"></i>${LEVELS[n].label}</button>`).join('');
    const voteBtn = (v, label) => `<button class="btn vote ${x.myVote === v ? 'mine' : ''}" data-action="vote" data-vote="${v}">${label}</button>`;

    return `
      <div class="detail">
        <button class="close" data-close aria-label="Close">×</button>
        <div class="gallery">${gallery}</div>
        <p class="eyebrow">${esc(CATEGORIES[s.category] || 'Space')}${s.floor ? ' · ' + esc(s.floor) : ''}</p>
        <h2>${esc(s.name)}</h2>
        <p class="muted" style="margin:2px 0 0">${esc(s.building)}</p>
        <div class="badges" style="margin-top:10px">
          <span class="badge occ ${lv ? lv.cls : 'none'}">${lv ? lv.label : 'No recent report'}</span>
          <span class="badge ${os.open === false ? 'closed' : ''}">${esc(os.text)}</span>
          ${s.is_verified ? '<span class="badge ok">✓ Verified</span>' : '<span class="badge">Unverified</span>'}
          ${s.capacity ? `<span class="badge">Seats ~${s.capacity}</span>` : ''}
        </div>
        ${s.description ? `<p>${esc(s.description)}</p>` : ''}

        <section>
          <h3>Live occupancy</h3>
          <div class="small muted">${lv
            ? `${lv.label} · ${s.live_report_count} report${s.live_report_count === 1 ? '' : 's'} · last ${ago(s.live_reported_at)}. Reports expire after ${WINDOW_MIN} min.`
            : `No report in the last ${WINDOW_MIN} minutes. Be the first to update it.`}</div>
          <div class="levels">${levelBtns}</div>
          <p class="small muted" style="margin:8px 0 0">${x.myReport
            ? `Thanks! You can update this space again at ${nextAt}.`
            : `How busy is it right now? You can report once per hour per space.`}</p>
        </section>

        <section>
          <h3>Getting there</h3>
          <dl class="kv">
            <dt>Coordinates</dt><dd>${s.latitude.toFixed(6)}, ${s.longitude.toFixed(6)}</dd>
            ${dist ? `<dt>From you</dt><dd>${dist}</dd>` : ''}
          </dl>
          <div class="row">
            <a class="btn primary" href="${dirUrl(s)}" target="_blank" rel="noopener">Directions</a>
            <a class="btn" href="${appleUrl(s)}" target="_blank" rel="noopener">Apple Maps</a>
            <button class="btn" data-action="copy">Copy coordinates</button>
            <button class="btn" data-action="fav">${fav ? '♥ Saved' : '♡ Save'}</button>
          </div>
        </section>

        <section>
          <h3>Wi-Fi, charging and facilities</h3>
          <div class="facilities">
            ${fac(s.has_wifi, 'Wi-Fi')}${fac(s.has_charging, 'Charging')}${fac(s.has_ac, 'A/C')}
            ${fac(s.has_water, 'Drinking water')}${fac(s.has_restroom, 'Restroom nearby')}
          </div>
        </section>

        <section>
          <h3>Opening hours</h3>
          <div>${esc(os.text)}</div>
        </section>

        <section>
          <h3>Accessibility</h3>
          <div class="facilities">
            ${fac(s.step_free, 'Step-free access')}${fac(s.has_elevator, 'Lift')}${fac(s.accessible_restroom, 'Accessible restroom')}
          </div>
          ${s.accessibility_notes ? `<p class="small muted" style="margin:8px 0 0">${esc(s.accessibility_notes)}</p>` : ''}
        </section>

        <section>
          <h3>Community check</h3>
          <div class="small muted">${s.confirm_count} confirmed · ${s.flag_count} flagged. Three confirmations (more than flags) verify a space.</div>
          ${mine ? '<p class="small muted">You added this space, so others will verify it.</p>' : `
          <div class="row">
            ${voteBtn('confirm', '✓ It exists & is quiet')}${voteBtn('fake', 'Not real')}${voteBtn('duplicate', 'Duplicate')}
          </div>`}
        </section>
      </div>`;
  }

  async function openDetail(id) {
    const s = state.spaces.find((x) => x.id === id);
    if (!s) return;
    state.selectedId = id;
    const dlg = $('#detailDialog');
    $('#detailBody').innerHTML = detailHTML(s, { photos: [], myReport: null, myVote: null });
    if (!dlg.open) dlg.showModal();
    try {
      if (state.map.getSize().x > 0) state.map.flyTo([s.latitude, s.longitude], Math.max(state.map.getZoom(), 18), { duration: .6 });
    } catch (e) { /* map hidden on mobile */ }
    render();
    const extras = await fetchExtras(s);
    if (state.selectedId === id && dlg.open) $('#detailBody').innerHTML = detailHTML(s, extras);
  }

  async function refreshDetail() {
    await loadSpaces();
    if (state.selectedId && $('#detailDialog').open) {
      const s = state.spaces.find((x) => x.id === state.selectedId);
      if (s) $('#detailBody').innerHTML = detailHTML(s, await fetchExtras(s));
    }
  }

  // ------------------------------------------------------------------
  // Actions: report, vote, favourite
  // ------------------------------------------------------------------
  function requireLogin() {
    if (!sb) { toast('Add your Supabase keys in js/config.js to enable this.', 'error'); return false; }
    if (!state.user) { toast('Please log in first.'); openAuth('login'); return false; }
    return true;
  }

  async function report(level) {
    if (!requireLogin()) return;
    const { error } = await sb.from('occupancy_reports').insert({ space_id: state.selectedId, level });
    if (error) return toast(error.message, 'error');
    toast(`Thanks! Status stays live for ${WINDOW_MIN} minutes.`);
    refreshDetail();
  }

  async function vote(v) {
    if (!requireLogin()) return;
    const id = state.selectedId;
    const { data: cur } = await sb.from('space_verifications').select('vote').eq('space_id', id)
      .eq('user_id', state.user.id).maybeSingle();
    let error;
    if (cur && cur.vote === v) ({ error } = await sb.from('space_verifications').delete().eq('space_id', id).eq('user_id', state.user.id));
    else ({ error } = await sb.from('space_verifications').upsert({ space_id: id, user_id: state.user.id, vote: v }, { onConflict: 'space_id,user_id' }));
    if (error) return toast(error.message, 'error');
    toast('Thanks for helping keep the map accurate.');
    refreshDetail();
  }

  async function toggleFav(id) {
    if (!requireLogin()) return;
    const had = state.favs.has(id);
    if (had) state.favs.delete(id); else state.favs.add(id);
    render();
    const q = had
      ? sb.from('favourites').delete().eq('space_id', id).eq('user_id', state.user.id)
      : sb.from('favourites').insert({ space_id: id, user_id: state.user.id });
    const { error } = await q;
    if (error) { toast(error.message, 'error'); loadFavs(); }
    if ($('#detailDialog').open && state.selectedId === id) refreshDetail();
  }

  // ------------------------------------------------------------------
  // Auth
  // ------------------------------------------------------------------
  let authMode = 'login';
  function openAuth(mode) {
    if (!sb) return toast('Add your Supabase keys in js/config.js to enable login.', 'error');
    setAuthMode(mode || 'login');
    $('#authError').hidden = true;
    $('#authDialog').showModal();
  }
  function setAuthMode(mode) {
    authMode = mode;
    $$('#authForm .tabs button').forEach((b) => b.classList.toggle('on', b.dataset.mode === mode));
    $('#authTitle').textContent = mode === 'login' ? 'Welcome back' : 'Create your account';
    $('#authSubmit').textContent = mode === 'login' ? 'Log in' : 'Sign up';
    $('.signup-only').hidden = mode === 'login';
    $('#authForm [name=password]').autocomplete = mode === 'login' ? 'current-password' : 'new-password';
  }
  async function submitAuth(e) {
    e.preventDefault();
    const f = e.target, err = $('#authError'); err.hidden = true;
    const email = f.email.value.trim(), password = f.password.value;
    if (!email || password.length < 8) { err.textContent = 'Enter a valid email and a password of at least 8 characters.'; err.hidden = false; return; }
    $('#authSubmit').disabled = true;
    let res;
    if (authMode === 'login') res = await sb.auth.signInWithPassword({ email, password });
    else res = await sb.auth.signUp({ email, password, options: { data: { display_name: f.display_name.value.trim() || email.split('@')[0] } } });
    $('#authSubmit').disabled = false;
    if (res.error) { err.textContent = res.error.message; err.hidden = false; return; }
    if (authMode === 'signup' && !res.data.session) {
      $('#authDialog').close(); toast('Check your email to confirm your account, then log in.'); return;
    }
    $('#authDialog').close(); f.reset();
    toast('Signed in. Welcome to QuietSpot!');
  }
  function updateAuthUI() {
    const b = $('#authBtn');
    b.textContent = state.user ? `Log out (${userName()})` : 'Log in';
  }

  // ------------------------------------------------------------------
  // Add space
  // ------------------------------------------------------------------
  function setPin(lat, lng, pan) {
    if (!state.pickMap) return;
    if (!state.pickMarker) {
      state.pickMarker = L.marker([lat, lng], { draggable: true }).addTo(state.pickMap);
      state.pickMarker.on('dragend', () => { const p = state.pickMarker.getLatLng(); setCoordInputs(p.lat, p.lng); });
    } else state.pickMarker.setLatLng([lat, lng]);
    if (pan) state.pickMap.setView([lat, lng], Math.max(state.pickMap.getZoom(), 18));
  }
  function setCoordInputs(lat, lng) {
    const f = $('#addForm');
    f.latitude.value = (+lat).toFixed(6); f.longitude.value = (+lng).toFixed(6);
  }
  function openAdd() {
    if (!requireLogin()) return;
    $('#addError').hidden = true;
    $('#addDialog').showModal();
    setTimeout(() => {
      if (!state.pickMap) {
        state.pickMap = L.map('pickMap').setView(CENTER, ZOOM);
        tiles().addTo(state.pickMap);
        state.pickMap.on('click', (ev) => { setPin(ev.latlng.lat, ev.latlng.lng); setCoordInputs(ev.latlng.lat, ev.latlng.lng); });
      }
      state.pickMap.invalidateSize();
    }, 60);
  }
  function locate(cb) {
    if (!navigator.geolocation) return toast('Location is not available on this device.', 'error');
    navigator.geolocation.getCurrentPosition(
      (p) => cb(p.coords.latitude, p.coords.longitude),
      () => toast('Could not get your location. Check browser permissions.', 'error'),
      { enableHighAccuracy: true, timeout: 10000 });
  }
  async function submitAdd(e) {
    e.preventDefault();
    const f = e.target, err = $('#addError'); err.hidden = true;
    const fail = (m) => { err.textContent = m; err.hidden = false; };
    const fd = new FormData(f);
    const text = (k) => (fd.get(k) || '').toString().trim();
    const bool = (k) => fd.get(k) === 'on';
    const lat = parseFloat(text('latitude')), lng = parseFloat(text('longitude'));
    if (text('name').length < 2 || text('building').length < 2) return fail('Please enter a name and building.');
    if (!isFinite(lat) || !isFinite(lng) || Math.abs(lat) > 90 || Math.abs(lng) > 180) return fail('Please set a valid location on the map or enter coordinates.');
    const files = fd.getAll('photos').filter((x) => x && x.size);
    if (files.length > 4) return fail('Please choose at most 4 photos.');
    for (const x of files) {
      if (!/^image\/(jpeg|png|webp)$/.test(x.type)) return fail('Photos must be JPG, PNG or WebP.');
      if (x.size > 5 * 1024 * 1024) return fail(`"${x.name}" is larger than 5 MB.`);
    }
    const dup = state.spaces.find((s) => distance([lat, lng], [s.latitude, s.longitude]) < 20 ||
      (s.name.toLowerCase() === text('name').toLowerCase() && s.building.toLowerCase() === text('building').toLowerCase()));
    if (dup && !confirm(`"${dup.name}" (${dup.building}) already exists very close to this pin. Add anyway?`)) return;

    const is24 = bool('is_24h');
    const payload = {
      name: text('name'), building: text('building'), category: text('category') || 'other',
      floor: text('floor') || null, description: text('description') || null,
      capacity: text('capacity') ? parseInt(text('capacity'), 10) : null,
      latitude: lat, longitude: lng,
      is_24h: is24, open_time: is24 ? null : (text('open_time') || null), close_time: is24 ? null : (text('close_time') || null),
      has_wifi: bool('has_wifi'), has_charging: bool('has_charging'), has_ac: bool('has_ac'),
      has_water: bool('has_water'), has_restroom: bool('has_restroom'),
      step_free: bool('step_free'), has_elevator: bool('has_elevator'), accessible_restroom: bool('accessible_restroom'),
      accessibility_notes: text('accessibility_notes') || null
    };
    $('#addSubmit').disabled = true; $('#addSubmit').textContent = 'Publishing…';
    const done = () => { $('#addSubmit').disabled = false; $('#addSubmit').textContent = 'Publish space'; };

    const { data: space, error } = await sb.from('spaces').insert(payload).select().single();
    if (error) {
      done();
      return fail(error.code === '23505' ? 'A space with that name already exists in that building.' : error.message);
    }
    let failed = 0;
    for (const file of files) {
      const ext = file.type === 'image/png' ? 'png' : file.type === 'image/webp' ? 'webp' : 'jpg';
      const path = `${state.user.id}/${space.id}/${crypto.randomUUID()}.${ext}`;
      const up = await sb.storage.from(BUCKET).upload(path, file, { contentType: file.type, cacheControl: '3600' });
      if (up.error) { failed++; continue; }
      const ins = await sb.from('space_photos').insert({ space_id: space.id, path });
      if (ins.error) failed++;
    }
    done();
    $('#addDialog').close(); f.reset(); $('#photoPreview').innerHTML = '';
    if (state.pickMarker) { state.pickMap.removeLayer(state.pickMarker); state.pickMarker = null; }
    toast(failed ? `Space added, but ${failed} photo(s) failed to upload.` : 'Space added. Thanks for sharing!', failed ? 'error' : '');
    await loadSpaces();
    openDetail(space.id);
  }

  // ------------------------------------------------------------------
  // Map
  // ------------------------------------------------------------------
  function tiles() {
    return L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19, attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    });
  }
  function initMap() {
    state.map = L.map('map', { zoomControl: true }).setView(CENTER, ZOOM);
    tiles().addTo(state.map);
    state.layer = L.layerGroup().addTo(state.map);
  }

  // ------------------------------------------------------------------
  // UI wiring
  // ------------------------------------------------------------------
  function bindUI() {
    $('#search').addEventListener('input', (e) => { state.filters.q = e.target.value; render(); });

    $$('.chip').forEach((c) => c.addEventListener('click', () => {
      const k = c.dataset.filter; state.filters[k] = !state.filters[k];
      c.setAttribute('aria-pressed', state.filters[k]); render();
    }));

    $('#sort').addEventListener('change', (e) => {
      state.sort = e.target.value;
      if (state.sort === 'near' && !state.userPos) {
        locate((lat, lng) => { state.userPos = [lat, lng]; render(); }, () => {});
        // fall back visually if permission denied
        setTimeout(() => { if (!state.userPos) { state.sort = 'quiet'; e.target.value = 'quiet'; render(); } }, 11000);
      } else render();
    });

    $('#list').addEventListener('click', (e) => {
      const fav = e.target.closest('[data-fav]');
      if (fav) { e.stopPropagation(); return toggleFav(fav.dataset.fav); }
      const card = e.target.closest('.card');
      if (card) openDetail(card.dataset.id);
    });
    $('#list').addEventListener('keydown', (e) => {
      if ((e.key === 'Enter' || e.key === ' ') && e.target.classList.contains('card')) { e.preventDefault(); openDetail(e.target.dataset.id); }
    });

    // dialogs: close buttons + backdrop click
    $$('dialog').forEach((d) => {
      d.addEventListener('click', (e) => { if (e.target === d || e.target.closest('[data-close]')) d.close(); });
    });
    $('#detailDialog').addEventListener('close', () => { state.selectedId = null; render(); });

    $('#detailBody').addEventListener('click', (e) => {
      const b = e.target.closest('[data-action]'); if (!b) return;
      const s = state.spaces.find((x) => x.id === state.selectedId); if (!s) return;
      if (b.dataset.action === 'report') report(+b.dataset.level);
      else if (b.dataset.action === 'vote') vote(b.dataset.vote);
      else if (b.dataset.action === 'fav') toggleFav(s.id);
      else if (b.dataset.action === 'copy') {
        const txt = `${s.latitude}, ${s.longitude}`;
        (navigator.clipboard ? navigator.clipboard.writeText(txt) : Promise.reject()).then(() => toast('Coordinates copied.'), () => toast(txt));
      }
    });

    // auth
    $('#authBtn').addEventListener('click', async () => {
      if (state.user) { await sb.auth.signOut(); toast('Logged out.'); } else openAuth('login');
    });
    $$('#authForm .tabs button').forEach((b) => b.addEventListener('click', () => setAuthMode(b.dataset.mode)));
    $('#authForm').addEventListener('submit', submitAuth);

    // add space
    $('#addBtn').addEventListener('click', openAdd);
    $('#addForm').addEventListener('submit', submitAdd);
    $('#addForm [name=is_24h]').addEventListener('change', (e) => {
      $('#hoursRow').style.opacity = e.target.checked ? .4 : 1;
      $$('#hoursRow input').forEach((i) => { i.disabled = e.target.checked; });
    });
    ['latitude', 'longitude'].forEach((n) => $('#addForm [name=' + n + ']').addEventListener('change', () => {
      const f = $('#addForm'), lat = parseFloat(f.latitude.value), lng = parseFloat(f.longitude.value);
      if (isFinite(lat) && isFinite(lng) && Math.abs(lat) <= 90 && Math.abs(lng) <= 180) setPin(lat, lng, true);
    }));
    $('#useMyLocation').addEventListener('click', () => locate((lat, lng) => { setCoordInputs(lat, lng); setPin(lat, lng, true); }));
    $('#photos').addEventListener('change', (e) => {
      const box = $('#photoPreview'); box.innerHTML = '';
      Array.from(e.target.files).slice(0, 4).forEach((f) => {
        const img = document.createElement('img'); img.alt = 'Selected photo preview';
        img.src = URL.createObjectURL(f); box.appendChild(img);
      });
    });

    // mobile list/map toggle
    $$('.mobile-toggle button').forEach((b) => b.addEventListener('click', () => {
      document.body.dataset.view = b.dataset.view;
      $$('.mobile-toggle button').forEach((x) => x.classList.toggle('on', x === b));
      setTimeout(() => state.map.invalidateSize(), 50);
    }));
    window.addEventListener('resize', () => state.map && state.map.invalidateSize());
  }

  // ------------------------------------------------------------------
  // Boot
  // ------------------------------------------------------------------
  async function init() {
    initMap(); bindUI();
    if (!sb) {
      const b = $('#banner');
      b.textContent = 'Demo mode: add your Supabase URL and anon key in js/config.js to enable login, photo uploads and live reports.';
      b.hidden = false;
    } else {
      const { data } = await sb.auth.getSession();
      state.user = (data.session && data.session.user) || null;
      sb.auth.onAuthStateChange((_evt, session) => {
        // defer: calling Supabase inside this callback can deadlock
        setTimeout(() => { state.user = (session && session.user) || null; updateAuthUI(); loadFavs(); }, 0);
      });
    }
    updateAuthUI();
    await loadSpaces();
    await loadFavs();

    // Live updates: refetch when anyone files a report, plus a refresh every minute
    // so 1-hour-old reports expire on screen without a page reload.
    if (sb) {
      let t;
      sb.channel('occupancy-live')
        .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'occupancy_reports' },
          () => { clearTimeout(t); t = setTimeout(loadSpaces, 400); })
        .subscribe();
    }
    setInterval(() => { if (!document.hidden) loadSpaces(); }, 60000);
  }

  init();
})();
