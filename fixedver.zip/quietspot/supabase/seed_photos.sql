-- =====================================================================
-- Add photos to the 4 default spaces
--
-- STEP 1  Supabase Dashboard > Storage > space-photos > Create folder "seed"
--         Upload your images into it, named exactly:
--           library.jpg   lecture-hall.jpg   engineering-block.jpg   lawn.jpg
--         (JPG/PNG/WebP, under 5 MB. If you use .png or .webp, change the
--          extension in the lines below.)
--
-- STEP 2  Run this file in SQL Editor.
-- =====================================================================

-- Allow admin/seed photos that have no uploader (safe to re-run; the
-- website policy still forces normal users to upload as themselves).
alter table public.space_photos alter column uploaded_by drop not null;

insert into public.space_photos (space_id, path, uploaded_by)
select s.id, v.path, null
from (values
  ('Silent Reading Hall', 'seed/library.jpg'),
  ('Lecture Hall 3',      'seed/lecture-hall.jpg'),
  ('Study Lounge',        'seed/engineering-block.jpg'),
  ('Central Lawn',        'seed/lawn.jpg')
) as v(space_name, path)
join public.spaces s on s.name = v.space_name
where not exists (
  select 1 from public.space_photos p where p.space_id = s.id and p.path = v.path
);

-- To add a second photo to a space later, upload it to seed/ and add a row, e.g.:
-- insert into public.space_photos (space_id, path, uploaded_by)
-- select id, 'seed/library-2.jpg', null from public.spaces where name = 'Silent Reading Hall';
