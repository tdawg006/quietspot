-- =====================================================================
-- QuietSpot — Supabase schema
-- Paste this whole file into: Supabase Dashboard > SQL Editor > New query > Run
-- Safe to re-run (uses IF NOT EXISTS / OR REPLACE / DROP POLICY IF EXISTS).
-- =====================================================================

-- ---------- 1. Profiles (one row per signed-up user) ----------------
create table if not exists public.profiles (
  id           uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  created_at   timestamptz not null default now()
);

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, display_name)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'display_name', split_part(new.email, '@', 1))
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ---------- 2. Spaces ------------------------------------------------
create table if not exists public.spaces (
  id                  uuid primary key default gen_random_uuid(),
  name                text not null check (char_length(name) between 2 and 100),
  building            text not null check (char_length(building) between 2 and 100),
  category            text not null default 'other'
                      check (category in ('library','lecture_hall','department','outdoor','cafe','other')),
  description         text check (description is null or char_length(description) <= 600),
  floor               text,
  capacity            int  check (capacity is null or capacity > 0),

  -- Map coordinates
  latitude            double precision not null check (latitude  between  -90 and  90),
  longitude           double precision not null check (longitude between -180 and 180),

  -- Opening hours (close_time < open_time means it closes after midnight)
  open_time           time,
  close_time          time,
  is_24h              boolean not null default false,

  -- Wi-Fi, charging and facilities
  has_wifi            boolean not null default false,
  has_charging        boolean not null default false,
  has_ac              boolean not null default false,
  has_water           boolean not null default false,
  has_restroom        boolean not null default false,

  -- Accessibility
  step_free           boolean not null default false,
  has_elevator        boolean not null default false,
  accessible_restroom boolean not null default false,
  accessibility_notes text check (accessibility_notes is null or char_length(accessibility_notes) <= 400),

  -- Community verification
  is_official         boolean not null default false,  -- seeded / admin spaces
  is_verified         boolean not null default false,  -- maintained by trigger, not by clients
  created_by          uuid default auth.uid() references auth.users(id) on delete set null,
  created_at          timestamptz not null default now()
);

-- Blocks exact duplicates (same name in the same building)
create unique index if not exists spaces_name_building_uq
  on public.spaces (lower(name), lower(building));

-- Clients may never change is_verified / is_official / created_by on update.
create or replace function public.guard_space_update()
returns trigger
language plpgsql
as $$
begin
  if current_user in ('anon', 'authenticated') then
    new.is_verified := old.is_verified;
    new.is_official := old.is_official;
    new.created_by  := old.created_by;
  end if;
  return new;
end;
$$;

drop trigger if exists spaces_guard on public.spaces;
create trigger spaces_guard
  before update on public.spaces
  for each row execute function public.guard_space_update();

-- ---------- 3. Photos -----------------------------------------------
create table if not exists public.space_photos (
  id          uuid primary key default gen_random_uuid(),
  space_id    uuid not null references public.spaces(id) on delete cascade,
  path        text not null,                       -- path inside the 'space-photos' bucket
  uploaded_by uuid default auth.uid() references auth.users(id) on delete cascade,  -- null = admin/seed photo
  created_at  timestamptz not null default now()
);
create index if not exists space_photos_space_idx on public.space_photos (space_id, created_at);

-- ---------- 4. Live occupancy reports -------------------------------
-- level: 1 = Empty, 2 = Quiet, 3 = Busy, 4 = Packed
-- A report counts as "live" for 1 hour. After that the space shows
-- "No recent report" until someone reports again.
create table if not exists public.occupancy_reports (
  id         uuid primary key default gen_random_uuid(),
  space_id   uuid not null references public.spaces(id) on delete cascade,
  user_id    uuid not null default auth.uid() references auth.users(id) on delete cascade,
  level      smallint not null check (level between 1 and 4),
  created_at timestamptz not null default now()
);
create index if not exists occupancy_space_time_idx on public.occupancy_reports (space_id, created_at desc);

-- One report per user per space per hour (prevents spam / vote stuffing)
create or replace function public.limit_report_rate()
returns trigger
language plpgsql
as $$
begin
  if exists (
    select 1 from public.occupancy_reports r
    where r.space_id = new.space_id
      and r.user_id  = new.user_id
      and r.created_at > now() - interval '1 hour'
  ) then
    raise exception 'You already reported this space in the last hour. Try again later.';
  end if;
  return new;
end;
$$;

drop trigger if exists occupancy_rate_limit on public.occupancy_reports;
create trigger occupancy_rate_limit
  before insert on public.occupancy_reports
  for each row execute function public.limit_report_rate();

-- ---------- 5. Favourites -------------------------------------------
create table if not exists public.favourites (
  user_id    uuid not null default auth.uid() references auth.users(id) on delete cascade,
  space_id   uuid not null references public.spaces(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, space_id)
);

-- ---------- 6. Community verification -------------------------------
create table if not exists public.space_verifications (
  id         uuid primary key default gen_random_uuid(),
  space_id   uuid not null references public.spaces(id) on delete cascade,
  user_id    uuid not null default auth.uid() references auth.users(id) on delete cascade,
  vote       text not null check (vote in ('confirm','fake','duplicate')),
  created_at timestamptz not null default now(),
  unique (space_id, user_id)
);

-- A space becomes verified at 3+ confirmations, as long as confirmations
-- outnumber "fake"/"duplicate" flags. Official spaces always stay verified.
create or replace function public.refresh_space_verification()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  sid uuid := coalesce(new.space_id, old.space_id);
  c   int;
  f   int;
begin
  select count(*) filter (where vote = 'confirm'),
         count(*) filter (where vote in ('fake','duplicate'))
    into c, f
    from public.space_verifications
   where space_id = sid;

  update public.spaces
     set is_verified = (is_official or (c >= 3 and c > f))
   where id = sid;
  return null;
end;
$$;

drop trigger if exists verification_refresh on public.space_verifications;
create trigger verification_refresh
  after insert or update or delete on public.space_verifications
  for each row execute function public.refresh_space_verification();

-- ---------- 7. Overview view used by the website --------------------
-- Rolls up live occupancy (last 1 hour), verification counts and cover photo.
create or replace view public.space_overview
with (security_invoker = true) as
select
  s.*,
  live.live_level,
  live.live_reported_at,
  coalesce(live.live_report_count, 0) as live_report_count,
  coalesce(v.confirm_count, 0)        as confirm_count,
  coalesce(v.flag_count, 0)           as flag_count,
  p.cover_path
from public.spaces s
left join lateral (
  select round(avg(r.level))::int as live_level,
         max(r.created_at)        as live_reported_at,
         count(*)::int            as live_report_count
  from public.occupancy_reports r
  where r.space_id = s.id
    and r.created_at > now() - interval '1 hour'
) live on true
left join lateral (
  select count(*) filter (where sv.vote = 'confirm')::int                  as confirm_count,
         count(*) filter (where sv.vote in ('fake','duplicate'))::int      as flag_count
  from public.space_verifications sv
  where sv.space_id = s.id
) v on true
left join lateral (
  select sp.path as cover_path
  from public.space_photos sp
  where sp.space_id = s.id
  order by sp.created_at
  limit 1
) p on true;

grant select on public.space_overview to anon, authenticated;

-- ---------- 8. Row Level Security -----------------------------------
alter table public.profiles            enable row level security;
alter table public.spaces              enable row level security;
alter table public.space_photos        enable row level security;
alter table public.occupancy_reports   enable row level security;
alter table public.favourites          enable row level security;
alter table public.space_verifications enable row level security;

-- profiles
drop policy if exists "profiles: read own"   on public.profiles;
drop policy if exists "profiles: update own" on public.profiles;
create policy "profiles: read own"   on public.profiles for select to authenticated using (id = (select auth.uid()));
create policy "profiles: update own" on public.profiles for update to authenticated using (id = (select auth.uid())) with check (id = (select auth.uid()));

-- spaces: anyone can read; logged-in users add; owners edit/delete their own
drop policy if exists "spaces: public read"  on public.spaces;
drop policy if exists "spaces: insert own"   on public.spaces;
drop policy if exists "spaces: update own"   on public.spaces;
drop policy if exists "spaces: delete own"   on public.spaces;
create policy "spaces: public read" on public.spaces for select to anon, authenticated using (true);
create policy "spaces: insert own"  on public.spaces for insert to authenticated
  with check (created_by = (select auth.uid()) and is_verified = false and is_official = false);
create policy "spaces: update own"  on public.spaces for update to authenticated
  using (created_by = (select auth.uid())) with check (created_by = (select auth.uid()));
create policy "spaces: delete own"  on public.spaces for delete to authenticated
  using (created_by = (select auth.uid()));

-- photos: public read; only the space's creator can attach / remove photos
drop policy if exists "photos: public read" on public.space_photos;
drop policy if exists "photos: insert own"  on public.space_photos;
drop policy if exists "photos: delete own"  on public.space_photos;
create policy "photos: public read" on public.space_photos for select to anon, authenticated using (true);
create policy "photos: insert own"  on public.space_photos for insert to authenticated
  with check (
    uploaded_by = (select auth.uid())
    and exists (select 1 from public.spaces s where s.id = space_id and s.created_by = (select auth.uid()))
  );
create policy "photos: delete own"  on public.space_photos for delete to authenticated
  using (uploaded_by = (select auth.uid()));

-- occupancy: public read; logged-in users report as themselves
drop policy if exists "occupancy: public read" on public.occupancy_reports;
drop policy if exists "occupancy: insert own"  on public.occupancy_reports;
create policy "occupancy: public read" on public.occupancy_reports for select to anon, authenticated using (true);
create policy "occupancy: insert own"  on public.occupancy_reports for insert to authenticated
  with check (user_id = (select auth.uid()));

-- favourites: private to each user
drop policy if exists "favourites: read own"   on public.favourites;
drop policy if exists "favourites: insert own" on public.favourites;
drop policy if exists "favourites: delete own" on public.favourites;
create policy "favourites: read own"   on public.favourites for select to authenticated using (user_id = (select auth.uid()));
create policy "favourites: insert own" on public.favourites for insert to authenticated with check (user_id = (select auth.uid()));
create policy "favourites: delete own" on public.favourites for delete to authenticated using (user_id = (select auth.uid()));

-- verification: public read (for counts); one vote per user; cannot vote on your own space
drop policy if exists "verif: public read"  on public.space_verifications;
drop policy if exists "verif: insert own"   on public.space_verifications;
drop policy if exists "verif: update own"   on public.space_verifications;
drop policy if exists "verif: delete own"   on public.space_verifications;
create policy "verif: public read" on public.space_verifications for select to anon, authenticated using (true);
create policy "verif: insert own"  on public.space_verifications for insert to authenticated
  with check (
    user_id = (select auth.uid())
    and not exists (select 1 from public.spaces s where s.id = space_id and s.created_by = (select auth.uid()))
  );
create policy "verif: update own"  on public.space_verifications for update to authenticated
  using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));
create policy "verif: delete own"  on public.space_verifications for delete to authenticated
  using (user_id = (select auth.uid()));

-- ---------- 9. Storage bucket for photos ----------------------------
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('space-photos', 'space-photos', true, 5242880, array['image/jpeg','image/png','image/webp'])
on conflict (id) do nothing;

drop policy if exists "space-photos: public read"  on storage.objects;
drop policy if exists "space-photos: upload own"   on storage.objects;
drop policy if exists "space-photos: delete own"   on storage.objects;
create policy "space-photos: public read" on storage.objects for select
  using (bucket_id = 'space-photos');
create policy "space-photos: upload own" on storage.objects for insert to authenticated
  with check (bucket_id = 'space-photos' and (storage.foldername(name))[1] = (select auth.uid())::text);
create policy "space-photos: delete own" on storage.objects for delete to authenticated
  using (bucket_id = 'space-photos' and (storage.foldername(name))[1] = (select auth.uid())::text);

-- ---------- 10. Realtime (live occupancy pushes to open browsers) ---
do $$
begin
  alter publication supabase_realtime add table public.occupancy_reports;
exception
  when duplicate_object then null;
end $$;

-- ---------- 11. Seed: the 4 starter spaces --------------------------
-- !! The coordinates below are PLACEHOLDERS around 28.6139, 77.2090.
-- !! Replace them with your real campus coordinates, e.g.:
-- !!   update public.spaces set latitude = 12.3456, longitude = 78.9012
-- !!   where name = 'Silent Reading Hall';
insert into public.spaces
  (name, building, category, description, floor, capacity, latitude, longitude,
   open_time, close_time, is_24h,
   has_wifi, has_charging, has_ac, has_water, has_restroom,
   step_free, has_elevator, accessible_restroom, accessibility_notes,
   is_official, is_verified)
values
  ('Silent Reading Hall', 'Central Library', 'library',
   'Strict-silence hall with individual carrels and desk lamps. Best for deep focus.',
   '2', 120, 28.6145, 77.2094,
   '08:00', '22:00', false,
   true, true, true, true, true,
   true, true, true, 'Ramp at main entrance; lift reaches all floors.',
   true, true),
  ('Lecture Hall 3', 'Lecture Hall Complex', 'lecture_hall',
   'Large hall that is usually empty between classes. Check the timetable board outside.',
   'Ground', 60, 28.6134, 77.2100,
   '09:00', '18:00', false,
   true, true, true, true, true,
   true, false, false, 'Step-free entrance from the east side. No lift needed (ground floor).',
   true, true),
  ('Study Lounge', 'Engineering Block', 'department',
   'Quiet corner lounge with long tables and power strips. Gets busy before labs.',
   '1', 40, 28.6149, 77.2077,
   '08:00', '20:00', false,
   true, true, true, true, true,
   false, true, false, 'Lift available; main entrance has two steps.',
   true, true),
  ('Central Lawn', 'Central Quad', 'outdoor',
   'Shaded lawn under the trees. Calm in the mornings, livelier after lunch.',
   null, null, 28.6130, 77.2086,
   null, null, true,
   false, false, false, true, false,
   true, false, false, 'Paved path runs to the edge of the lawn.',
   true, true)
on conflict do nothing;
