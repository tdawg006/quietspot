# QuietSpot

Find a quiet spot on campus. Static site (HTML/CSS/JS) + Supabase, deployable on Netlify with no build step.

## Features
- Map (OpenStreetMap/Leaflet) + list, directions to each space, copy coordinates
- Search by name or building; filters for open now, quiet now, Wi-Fi, charging, step-free, favourites
- Log in / sign up (Supabase Auth); logged-in users add spaces with photos and map coordinates
- Add a location by tapping the map, dragging the pin, typing lat/lng, or using current GPS position
- Live occupancy: one report per user per space per hour; a report is shown for 1 hour, then expires
- Favourites, community verification (3 confirmations = verified; flags for fake/duplicate)
- Wi-Fi/charging/facilities, opening hours (incl. past-midnight and 24h), accessibility info
- 4 starter spaces: Library, Lecture Hall, Engineering Block, Lawn

## Setup (about 10 minutes)

### 1. Supabase
1. Create a project at https://supabase.com.
2. Open **SQL Editor > New query**, paste all of `supabase/schema.sql`, click **Run**.
   This creates tables, security policies, the photo bucket, realtime and the 4 seed spaces.
3. **Authentication > Providers > Email** is on by default. For quick testing, turn off
   "Confirm email" (or keep it on and confirm via the email link).
4. **Project Settings > API**: copy the **Project URL** and the **anon public** key.

### 2. Configure the site
Edit `js/config.js`:
- `SUPABASE_URL`, `SUPABASE_ANON_KEY`: from step 1.4 (never use the service_role key)
- `CAMPUS_CENTER`: `[latitude, longitude]` of your campus

The seeded spaces use placeholder coordinates. Move them to your real campus, e.g.:
```sql
update public.spaces set latitude = 12.3456, longitude = 78.9012 where name = 'Silent Reading Hall';
```

### 3. Deploy on Netlify
- Easiest: unzip, go to https://app.netlify.com/drop and drag the `quietspot` folder in.
- Or push the folder to GitHub and import it in Netlify (no build command; publish directory `.`).

### 4. Final Supabase step
After you get your Netlify URL: **Authentication > URL Configuration**, set **Site URL** to it
and add it to **Redirect URLs** so email confirmation links work.

## Notes
- Without keys in `config.js` the site runs in read-only demo mode.
- The anon key is public by design. Security comes from the Row Level Security policies in the schema.
- Free OpenStreetMap tiles are for light use; switch the tile provider in `js/app.js` for heavy traffic.
- Photos are stored in the public `space-photos` bucket (5 MB limit, JPG/PNG/WebP).

## Structure
```
index.html         page and dialogs
css/style.css      styles (light + dark)
js/config.js       your keys and campus centre
js/app.js          app logic
supabase/schema.sql  database, policies, storage, seed data
netlify.toml       Netlify settings
```
